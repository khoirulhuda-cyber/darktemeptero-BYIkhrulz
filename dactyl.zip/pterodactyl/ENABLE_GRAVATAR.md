First of all you should issue the following commands:

``yarn add react-gravatar``
``yarn add @types/react-gravatar --save-dev``


Now open the folder only for gravatar and upload the files
in ``/var/www/pterodactyl`` directory.

After that issue the following command:
``yarn run build:production``
