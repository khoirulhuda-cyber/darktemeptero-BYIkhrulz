# Dactyl-Theme

# How to install:
First of all make sure you use the default theme provided by Pterodactyl.io .
Open the resources folder and replace the files with Dactyl Theme file.
For colors replace ``tailwind.config.js`` .

Open the directory ``/var/www/pterodactyl`` and replace the files ``resources`` and ``tailwind.config.js``.

Now we need to open the terminal, access the website location and run the following commands:
- ``yarn install``
- ``yarn run build:production``

# Edit colors
90% of theme colors can be changed from ``tailwind.config.js``, from the object ``dactyl``.

# Edit logo
The logo can be edited from ``resources/scripts/assets/images``. Just replace ``logo.svg`` and ``logo-dark.svg``.

# Don't forget
For any changes you make to the theme, you should run the command ``yarn run build:production`` or run ``yarn run watch``, so the files will be built automatically for each change in theme.

# Bugs & Help
Did you find a problem with the theme?
Do you have difficulty installing the theme?

Contact me on Discord, and I will try to answer as soon as possible.

# Contact
- Discord: ``TheoDoR#6332``
- Discord server: https://discord.gg/erm5B7ceRe
